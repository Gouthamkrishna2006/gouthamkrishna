Hello there Goutham here,

Keep these in mind:

The data for this app is stored in your device itself and therefore the app will need access to creating, editing and deleting its files.
The default location of installation of the app is in the programs folder, and the app will require admistrator access to perform properly.

You can either run the app as administrator always (it will prompt you everytime you open the app)
or you can change the installation location to somewhere it doesnt require administrator access, and it should work perfectly.

If you face any issues with the app, or have any suggestions, please do contact me.

Just click the top left or top right of the application in the login or register page to get access to my contact.

Enjoy :)